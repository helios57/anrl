{\rtf1\mac\ansicpg10000\cocoartf824\cocoasubrtf480
{\fonttbl\f0\fswiss\fcharset77 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 Supports the following Windows Operating Systems:\
 - Windows 98SE\
 - Windows ME\
 - Windows 2000 SP4\
 - Windows XP SP2 and above (32 & 64 bit)\
 - Windows Server 2003 (32 & 64 bit)\
 - Windows Server 2008 / 2008 R2 (32 & 64 bit)\
 - Windows Vista (32 & 64 bit)\
 - Windows 7 (32 & 64 bit)\
 \'ca \'ca \'ca NOTE: For Windows 7, please use RC build 7100 or above.\
 \'ca. USB host controller\
 \'ca. Device using PL-2303H/HX/X version chip}